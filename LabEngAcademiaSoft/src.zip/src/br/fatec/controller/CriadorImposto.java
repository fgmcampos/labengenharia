package br.fatec.controller;

import br.fatec.view.Imposto;

public class CriadorImposto extends Imposto {

	@Override
	public double calcula(Imposto valorImposto) {
		
		return 0;
	}

}
