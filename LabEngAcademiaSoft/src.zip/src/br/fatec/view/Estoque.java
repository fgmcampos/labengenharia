package br.fatec.view;

import java.util.List;

public class Estoque {

	private List<ProdutoEmEstoque> listaProdutos;

	public void add(Produto p) {

	}

	public void remove(Produto p) {

	}

}
